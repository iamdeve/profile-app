import React from 'react';
import Modal from 'react-bootstrap/Modal';
import '../css/common.css';
import { Link } from 'react-router-dom';
function HorizontalModal(props) {
	return (
		<>
			<Modal {...props} size='lg' aria-labelledby='contained-modal-title-vcenter' centered>
				<Modal.Body style={{ overflow: 'auto' }}>
					<div className='modal-bg' style={{ background: `url(${props.image})` }}></div>
				</Modal.Body>
				<Modal.Footer>
					<div className='mb-2 fontfamily'>
						{props.underline ? (
							<Link style={{ textDecoration: 'underline' }} to='/somewher'>
								{props.description}
							</Link>
						) : (
							<span>{props.description}</span>
						)}
					</div>
				</Modal.Footer>
			</Modal>
		</>
	);
}

export default HorizontalModal;
