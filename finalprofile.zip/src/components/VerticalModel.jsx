import React from 'react';
import Modal from 'react-bootstrap/Modal';
import '../css/common.css';
import { Link } from 'react-router-dom';
function VerticalModel(props) {
	console.log('prpos');
	return (
		<Modal {...props} size='sm' aria-labelledby='contained-modal-title-vcenter' centered style={{ width: '100%' }}>
			<Modal.Body contentClassName='height' style={{ overflow: 'scroll' }}>
				<div className='modal-bg' style={{ background: `url(${props.image})` }}></div>
				{/* <img className="v-model-image-size" src={props.image} alt="vertical" /> */}
			</Modal.Body>
			<Modal.Footer>
				<div className='mb-2 fontfamily'>
					{props.underline ? (
						<Link style={{ textDecoration: 'underline' }} to='/somewher'>
							{props.description}
						</Link>
					) : (
						<span>{props.description}</span>
					)}
				</div>
			</Modal.Footer>
		</Modal>
	);
}

export default VerticalModel;
